from django.apps import AppConfig


class MapConfig(AppConfig):
    name = 'map'
    verbose_name = '2. Настройки карт'
