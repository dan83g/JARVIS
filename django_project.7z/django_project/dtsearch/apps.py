from django.apps import AppConfig


class DtsearchConfig(AppConfig):
    name = 'dtsearch'
    verbose_name = '3. Настройки dtSearch'
