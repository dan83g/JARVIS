import pytz
from JARVIS import enums


LANGUAGE_CODE = 'ru-RU'
TIME_ZONE = enums.TZ
TZ = pytz.timezone(TIME_ZONE)
USE_I18N = True
USE_L10N = True
USE_TZ = True
