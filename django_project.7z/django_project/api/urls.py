from django.urls import path
from . import views

urlpatterns = [
    # ocr
    path('v1/ocr', views.ocr),

    # ping
    # path('v1/ping', views.ping),

    # type
    # path('v1/type.list', views.type_list),

    # query
    path('v1/query.list', views.query_list),
    path('v1/query.data', views.query_data),
]
